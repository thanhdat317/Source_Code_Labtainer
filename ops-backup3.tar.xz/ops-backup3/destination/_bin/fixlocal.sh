#!/bin/bash
# Labtainer post-parameterization hook.
# Kept intentionally small; Dockerfile prepares the lab environment.
exit 0
