<?php
error_reporting(E_ERROR | E_PARSE);



$error = $content = '';

if (isset($_GET['url'])) {
    if (!filter_var($_GET['url'], FILTER_VALIDATE_URL)) { 
        $error = 'Not a valid url';
    } else {
        $content = base64_encode(file_get_contents($_GET['url']));
    }
}
?>
<html>

<head>
    <!-- For UX/UI only -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
</head>

<body>
    <!-- <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="nav-item nav-link" href="/backup.php">Admin</a>
    </nav> -->
    <div class="container">
        <br />
        <br /><br />
        <h4>Image preview service</h4>
        <p></p>
        <form>
            <input type="text" name="url" class="form-control" placeholder="https://miro.medium.com/v2/resize:fit:640/0*ngAthWxOvKZHvsw9"><br />
            <input type="submit" class="button btn btn-success" value="Submit">
        </form>
        
        <?php  {
            echo '<img src="data:image/png;base64, ' . $content . '">';
        } ?>
        <p class="text-danger"><?php echo $error; ?></p>
    </div>
</body>

</html>
