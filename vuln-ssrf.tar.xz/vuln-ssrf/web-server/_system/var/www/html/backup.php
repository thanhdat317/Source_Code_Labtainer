<?php
if ($_SERVER['REMOTE_ADDR'] === "100.0.0.15") {
    die("admin:100e8a82eea1ef8416e585433fd8462e");
}
http_response_code(403);
die("Error 403 forbidden, can only be accessed by localhost");
?>

