!/bin/bash
#
#  This script will be run after parameterization has completed, e.g., 
#  use this to compile source code that has been parameterized.
#  The container user password will be passed as the first argument,
#  (the user ID is the second parameter)
#  If this script is to use sudo and the sudoers for the lab
#  does not permit nopassword, then use:
#  echo $1 | sudo -S the-command
#
#  If you issue commands herein to start services, and those services
#  have unit files prescribing their being started after the
#  waitparam.service, then first create the flag directory that
#  waitparam sleeps on:
#
#   PERMLOCKDIR=/var/labtainer/did_param
#   echo $1 | sudo -S mkdir -p "$PERMLOCKDIR"

#systemctl start apache2 
#systemctl enable apache2 
#systemctl start mariadb 
#systemctl enable mariadb 
#systemctl restart apache2
sudo -S systemctl start apache2
sudo -S systemctl enable apache2
sudo -S systemctl start mariadb
sudo -S systemctl enable mariadb
sudo -S systemctl restart apache2
sudo -S rm /var/www/html/index.html

